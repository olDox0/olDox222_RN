# -*- coding: utf-8 -*-
# engine/server/server.py
"""
ORN — SiCDox Server
Servidor local de inferência. Carrega o modelo UMA VEZ, serve continuamente.

Protocolo (TCP local):
  Request:  JSON linha {"prompt": "...", "max_tokens": 128}
  Response: JSON linha {"output": "...", "elapsed_s": 1.23, "error": null}

Comando especial:
  b"STATUS\n" -> JSON com uptime, requests, errors e métricas

OSL-3:  Modelo carregado uma vez no startup.
OSL-7:  Toda requisição retorna JSON com "error" explícito.
OSL-15: Erros de inferência não derrubam o servidor.
OSL-18: stdlib + dependências do projeto.
God: Hefesto — fornalha contínua; a forja não apaga entre peças.
"""

from __future__ import annotations
# [DOXOADE:VULCAN]
# [VULCAN-SKIP] Proteção contra introspecção Click
import os, sys; _b = os.path.join(os.getcwd(), ".doxoade", "vulcan", "bootstrap.py")
if os.path.exists(_b):
    import importlib.util as _u; _s = _u.spec_from_file_location("_vb", _b)
    _m = _u.module_from_spec(_s); _s.loader.exec_module(_m); _m.ignite(__file__, globals())
# [/DOXOADE:VULCAN]

import json
import os
import signal
import socket
import subprocess
import sys
import threading
import time
import traceback
from pathlib import Path
from typing import Any

from engine.core.cpu_affinity import apply_process_affinity
from engine.server import server_bootstrap, server_utils
from engine.telemetry import GLOBAL_TELEMETRY, orn_probe

_shutdown_event = threading.Event()

HOST = "127.0.0.1"
PORT = 8371
BACKLOG = 4
RECV_SZ = 65536

PID_FILE = Path("server.pid")
LOG_FILE = Path("server.log")

_llm = None
_native = None
_cfg = None
_lock = threading.Lock()
_system_tokens = None

_stats: dict[str, Any] = {
    "requests": 0,
    "errors": 0,
    "total_tokens": 0,
    "total_elapsed_s": 0.0,
    "start": None,
    "infer_calls": 0,
    "last_infer_s": 0.0,
    "last_prompt_chars": 0,
    "last_output_chars": 0,
    "last_max_tokens": 0,
    "sum_prompt_chars": 0,
    "sum_output_chars": 0,
    "last_llm_call_ms": 0.0,
    "last_lock_wait_ms": 0.0,
    "sum_llm_call_ms": 0.0,
    "sum_lock_wait_ms": 0.0,
}

_boot_perf = {
    "vulcan_boot_ms": 0.0,
    "model_load_ms": 0.0,
}

_VULCAN_ACTIVE = False
_VULCAN_MSG = ""

try:
    import llama_cpp
except Exception:
    pass

# ---------------------------------------------------------------------------
# Bootstrap do doxoade / Vulcan
# ---------------------------------------------------------------------------

def _looks_like_doxoade_root(path_str: str | None) -> bool:
    return server_bootstrap.looks_like_doxoade_root(path_str)


def _discover_doxoade_root() -> str | None:
    return server_bootstrap.discover_doxoade_root()


def _vulcan_boot() -> tuple[bool, str]:
    return server_bootstrap.vulcan_boot()


_t_boot0 = time.monotonic()
_VULCAN_ACTIVE, _VULCAN_MSG = _vulcan_boot()
_boot_perf["vulcan_boot_ms"] = round((time.monotonic() - _t_boot0) * 1000.0, 3)

if _VULCAN_ACTIVE:
    print(f"[VULCAN] OK — {_VULCAN_MSG}", flush=True)
else:
    for _line in _VULCAN_MSG.splitlines():
        print(f"[VULCAN] {_line}", flush=True)
    print("[VULCAN] Continuando com Python puro (OSL-15).", flush=True)


# ---------------------------------------------------------------------------
# Telemetria / utilidades
# ---------------------------------------------------------------------------

def _observe_telemetry(name: str, elapsed_ms: float, *, category: str = "exec") -> None:
    server_utils.observe_telemetry(name, elapsed_ms, category=category)


def _flush_telemetry_snapshot() -> None:
    server_utils.flush_telemetry_snapshot()


def _system_perf_snapshot() -> dict[str, Any]:
    return server_utils.system_perf_snapshot()


def _json_line(resp: dict[str, Any]) -> bytes:
    return server_utils.json_line(resp)


def _read_line_from_socket(conn: socket.socket, timeout: float = 10.0) -> str:
    return server_utils.read_line_from_socket(conn, RECV_SZ, timeout=timeout)


# ---------------------------------------------------------------------------
# Modelo
# ---------------------------------------------------------------------------

def _load_model() -> None:
    global _llm, _cfg, _native
    from engine.core.llm_bridge import BridgeConfig
    _cfg = BridgeConfig()
    try:
        applied, detail = apply_process_affinity(_cfg.cpu_mask, _cfg.cpuset)
        if applied: print(f"[CPU-AFFINITY] {detail}", flush=True)
    except Exception as exc:
        print(f"[CPU-AFFINITY] falha ao aplicar: {exc}", flush=True)

    if not _cfg.model_path.exists():
        print(f"[ERRO] Modelo nao encontrado: {_cfg.model_path}", flush=True)
        sys.exit(1)

    dll = Path(__file__).parent.parent.parent / "native" / "orn.dll"
    _use_native = dll.exists()
    if not _use_native:
        _use_native = os.environ.get("ORN_NATIVE_BACKEND", "").lower() in {"1", "true", "on"}

    if _use_native:
        from engine.core.native_backend import NativeBackend
        _native = NativeBackend(
            dll_path=dll,
            model_path=_cfg.model_path,
            n_ctx=_cfg.n_ctx,
            n_threads=_cfg.n_threads,
        )
        t0 = time.monotonic()
        try:
            _native.load()
            elapsed_ms = round((time.monotonic() - t0) * 1000.0, 3)
            _boot_perf["model_load_ms"] = elapsed_ms
            _observe_telemetry("server.boot.model_load", elapsed_ms, category="boot")
            _stats["start"] = time.monotonic()
            print(f"[BOOT] orn.dll ativo [{dll}]", flush=True)
            print(f"[BOOT] nativo cfg n_ctx={_cfg.n_ctx} n_threads={_cfg.n_threads}", flush=True)
            return
        except Exception as exc:
            print(f"[BOOT] orn.dll indisponivel ({exc}) — fallback llama-cpp-python", flush=True)
            _native = None

    from llama_cpp import Llama
    backend = "VULCAN/nativo" if _VULCAN_ACTIVE else "Python puro"
    print(f"[BOOT] {_cfg.model_path.name}  [{backend}]", flush=True)
    print(f"[BOOT] n_threads={_cfg.n_threads}  n_ctx={_cfg.n_ctx}", flush=True)
    t0 = time.monotonic()
    kwargs: dict[str, Any] = {
        "model_path": str(_cfg.model_path),
        "n_ctx": _cfg.n_ctx,
        "n_threads": _cfg.n_threads,
        "n_gpu_layers": _cfg.n_gpu_layers,
        "n_batch": _cfg.n_batch,
        "n_threads_batch": _cfg.n_threads_batch,
        "use_mmap": _cfg.use_mmap,
        "use_mlock": _cfg.use_mlock,
        "verbose": False,
    }
    if _cfg.cache_type_k: kwargs["type_k"] = _cfg.cache_type_k
    if _cfg.cache_type_v: kwargs["type_v"] = _cfg.cache_type_v
    if _cfg.rope_freq_base is not None: kwargs["rope_freq_base"] = _cfg.rope_freq_base
    if _cfg.rope_freq_scale is not None: kwargs["rope_freq_scale"] = _cfg.rope_freq_scale
    if _cfg.flash_attn is not None: kwargs["flash_attn"] = _cfg.flash_attn
    if _cfg.no_alloc: kwargs["no_alloc"] = True
    if _cfg.pin_threads: kwargs["pin_threads"] = True
    if _cfg.cont_batching: kwargs["cont_batching"] = True
    try:
        _llm = Llama(**kwargs)
    except TypeError as exc:
        unsupported = (
            "type_k", "type_v", "rope_freq_base", "rope_freq_scale", "flash_attn",
            "no_alloc", "use_mmap", "pin_threads", "cont_batching",
        )
        if not any(tok in str(exc) for tok in unsupported): raise
        for tok in unsupported: kwargs.pop(tok, None)
        _llm = Llama(**kwargs)

    elapsed_ms = round((time.monotonic() - t0) * 1000.0, 3)
    _boot_perf["model_load_ms"] = elapsed_ms
    _observe_telemetry("server.boot.model_load", elapsed_ms, category="boot")
    _stats["start"] = time.monotonic()

    global _system_tokens
    try:
        system_str = f"<|im_start|>system\n{_cfg.system_prompt}<|im_end|>\n"
        try: _system_tokens = _llm.tokenize(system_str.encode("utf-8"), special=True)
        except TypeError: _system_tokens = _llm.tokenize(system_str.encode("utf-8"))
    except Exception:
        _system_tokens = None
    print(f"[BOOT] Pronto em {round(elapsed_ms / 1000.0, 1)}s — {HOST}:{PORT}", flush=True)


@orn_probe(category="exec", critical=True, probe_name="server.infer")
def _infer(prompt: str, max_tokens: int) -> tuple[str, float]:
    if (_llm is None and _native is None) or _cfg is None:
        raise RuntimeError("Modelo nao carregado.")

    if _native is not None:
        t0 = time.monotonic()

        system_block = f"<|im_start|>system\n{_cfg.system_prompt}<|im_end|>\n"
        asst_block   = "<|im_start|>assistant\n"

        # Estimativa conservadora: 3 chars ≈ 1 token (pt-BR + código)
        # Reserva espaço para os tokens de output + margem de segurança (128)
        max_user_chars = (_cfg.n_ctx - max_tokens - 128) * 3 - len(system_block) - len(asst_block)

        user_prompt = prompt
        if max_user_chars > 0 and len(prompt) > max_user_chars:
            user_prompt = prompt[:max_user_chars - 30] + "\n[contexto truncado]"
            print(f"[NATIVE] Prompt truncado: {len(prompt)} → {len(user_prompt)} chars", flush=True)

        native_prompt = (
            system_block
            + f"<|im_start|>user\n{user_prompt}<|im_end|>\n"
            + asst_block
        )

        out = _native.call(native_prompt, max_tokens)
        elapsed = round(time.monotonic() - t0, 3)
        llm_call_ms = float(out.get("llm_call_ms", elapsed * 1000.0))
        _observe_telemetry("server.infer.lock_wait", 0.0)
        _observe_telemetry("server.infer.llm_call", llm_call_ms)
        with _lock:
            _stats["last_lock_wait_ms"] = 0.0
            _stats["last_llm_call_ms"]  = round(llm_call_ms, 4)
            _stats["sum_llm_call_ms"]  += llm_call_ms
        return str(out.get("text", "")).strip(), elapsed

    global _system_tokens
    prompt_input = None

    # Tenta usar os tokens pré-calculados (Prompt Caching) para pular processamento
    if _system_tokens is not None:
        try:
            user_str = f"<|im_start|>user\n{prompt}<|im_end|>\n<|im_start|>assistant\n"
            try:
                user_tokens = _llm.tokenize(user_str.encode("utf-8"), special=True)
            except TypeError:
                user_tokens = _llm.tokenize(user_str.encode("utf-8"))
            prompt_input = _system_tokens + user_tokens
        except Exception:
            pass

    # Fallback caso a tokenização manual falhe
    if prompt_input is None:
        prompt_input = (
            f"<|im_start|>system\n{_cfg.system_prompt}<|im_end|>\n"
            f"<|im_start|>user\n{prompt}<|im_end|>\n"
            f"<|im_start|>assistant\n"
        )

    t0 = time.monotonic()
    t_wait0 = t0

    with _lock:
        lock_wait_ms = (time.monotonic() - t_wait0) * 1000.0
        t_llm0 = time.monotonic()

        infer_kwargs: dict[str, Any] = {
            "max_tokens": max_tokens,
            "stop": ["<|im_end|>", "</s>", "| stopgen |", "|stopgen|"],
            "echo": False,
            "temperature": _cfg.temperature,
            "top_p": _cfg.top_p,
            "top_k": _cfg.top_k,
            "repeat_penalty": _cfg.repeat_penalty,
        }

        min_p = getattr(_cfg, "min_p", None)
        if min_p is not None:
            infer_kwargs["min_p"] = float(min_p)

        # Chama o LLM passando a lista de tokens numéricos (MUITO mais rápido) ou a string bruta
        try:
            out = _llm(prompt_input, **infer_kwargs)
        except Exception:
            # Se a versão do llama-cpp-python não aceitar lista de tokens, faz fallback seguro pra string
            if isinstance(prompt_input, list):
                fallback_str = (
                    f"<|im_start|>system\n{_cfg.system_prompt}<|im_end|>\n"
                    f"<|im_start|>user\n{prompt}<|im_end|>\n"
                    f"<|im_start|>assistant\n"
                )
                out = _llm(fallback_str, **infer_kwargs)
            else:
                raise

    llm_call_ms = (time.monotonic() - t_llm0) * 1000.0

    # VVV ADICIONE ESTE BLOCO DE VOLTA VVV
    _observe_telemetry("server.infer.lock_wait", lock_wait_ms)
    _observe_telemetry("server.infer.llm_call", llm_call_ms)

    with _lock:
        _stats["last_lock_wait_ms"] = round(lock_wait_ms, 4)
        _stats["last_llm_call_ms"] = round(llm_call_ms, 4)
        _stats["sum_lock_wait_ms"] += lock_wait_ms
        _stats["sum_llm_call_ms"] += llm_call_ms

    elapsed = round(time.monotonic() - t0, 3)
    return out["choices"][0]["text"].strip(), elapsed


def _infer_stream(prompt: str, max_tokens: int):
    if (_llm is None and _native is None) or _cfg is None:
        raise RuntimeError("Modelo nao carregado.")

    if _native is not None:
        # Monta o prompt formatado (igual ao _infer)
        system_block = f"<|im_start|>system\n{_cfg.system_prompt}<|im_end|>\n"
        asst_block   = "<|im_start|>assistant\n"
        max_user_chars = (_cfg.n_ctx - max_tokens - 128) * 3 \
                         - len(system_block) - len(asst_block)
        user_prompt = prompt
        if max_user_chars > 0 and len(prompt) > max_user_chars:
            user_prompt = prompt[:max_user_chars - 30] + "\n[contexto truncado]"

        native_prompt = (
            system_block
            + f"<|im_start|>user\n{user_prompt}<|im_end|>\n"
            + asst_block
        )

        t0      = time.monotonic()
        pieces  = []
        try:
            for piece in _native.stream(native_prompt, max_tokens):
                pieces.append(piece)
                yield {"delta": piece, "done": False}
        except Exception as exc:
            yield {"delta": "", "done": True, "elapsed_s": 0,
                   "error": str(exc)}
            return

        elapsed = round(time.monotonic() - t0, 3)
        yield {"delta": "".join(pieces), "done": True, "elapsed_s": elapsed}
        return

    prompt_input = (
        f"<|im_start|>system\n{_cfg.system_prompt}<|im_end|>\n"
        f"<|im_start|>user\n{prompt}<|im_end|>\n"
        f"<|im_start|>assistant\n"
    )
    infer_kwargs: dict[str, Any] = {
        "max_tokens": max_tokens,
        "stop": ["<|im_end|>", "</s>"],
        "echo": False,
        "temperature": _cfg.temperature,
        "top_p": _cfg.top_p,
        "top_k": _cfg.top_k,
        "repeat_penalty": _cfg.repeat_penalty,
        "stream": True,
    }
    min_p = getattr(_cfg, "min_p", None)
    if min_p is not None:
        infer_kwargs["min_p"] = float(min_p)

    t0 = time.monotonic()
    acc: list[str] = []
    for item in _llm(prompt_input, **infer_kwargs):
        delta = str(item["choices"][0].get("text", ""))
        if not delta:
            continue
        acc.append(delta)
        yield {"delta": delta, "done": False}
    elapsed = round(time.monotonic() - t0, 3)
    yield {"delta": "".join(acc), "done": True, "elapsed_s": elapsed}


# ---------------------------------------------------------------------------
# Status
# ---------------------------------------------------------------------------

def _telemetry_hotspots(limit: int = 3) -> list[dict[str, Any]]:
    try:
        snap = GLOBAL_TELEMETRY.snapshot()
    except Exception:
        return []

    rows: list[dict[str, Any]] = []
    for name, stats in snap.items():
        calls = int(stats.get("calls", 0) or 0)
        avg_ms = float(stats.get("avg_ms", 0) or 0)
        rows.append(
            {
                "name": name,
                "calls": calls,
                "avg_ms": avg_ms,
                "p95_ms": float(stats.get("p95_ms", 0) or 0),
                "total_ms": round(calls * avg_ms, 4),
            }
        )

    rows.sort(key=lambda x: x["total_ms"], reverse=True)
    return rows[: max(1, limit)]


def _handle_status() -> dict[str, Any]:
    up = round(time.monotonic() - _stats["start"], 1) if _stats["start"] else 0
    req = _stats["requests"]
    avg = round(_stats["total_elapsed_s"] / req, 3) if req > 0 else 0
    infer_calls = _stats["infer_calls"]

    avg_prompt_chars = round(_stats["sum_prompt_chars"] / infer_calls, 2) if infer_calls else 0
    avg_output_chars = round(_stats["sum_output_chars"] / infer_calls, 2) if infer_calls else 0
    last_tokens_per_s = round((_stats["last_max_tokens"] / _stats["last_infer_s"]) if _stats["last_infer_s"] else 0, 3)
    total_tokens_per_s = round((_stats["total_tokens"] / _stats["total_elapsed_s"]) if _stats["total_elapsed_s"] else 0, 3)
    last_output_chars_per_s = round((_stats["last_output_chars"] / _stats["last_infer_s"]) if _stats["last_infer_s"] else 0, 3)
    avg_lock_wait_ms = round((_stats["sum_lock_wait_ms"] / infer_calls) if infer_calls else 0, 4)
    avg_llm_call_ms = round((_stats["sum_llm_call_ms"] / infer_calls) if infer_calls else 0, 4)
    last_non_llm_ms = round(max((_stats["last_infer_s"] * 1000.0) - _stats["last_llm_call_ms"], 0.0), 4)
    last_llm_share_pct = round((_stats["last_llm_call_ms"] / (_stats["last_infer_s"] * 1000.0) * 100.0) if _stats["last_infer_s"] else 0, 2)

    return {
        "status": "online",
        "uptime_s": up,
        "requests": req,
        "errors": _stats["errors"],
        "total_tokens": _stats["total_tokens"],
        "avg_elapsed_s": avg,
        "port": PORT,
        "vulcan": _VULCAN_ACTIVE,
        "vulcan_detail": _VULCAN_MSG,
        "boot_perf": dict(_boot_perf),
        "system_perf": _system_perf_snapshot(),
        "ai_perf": {
            "infer_calls": infer_calls,
            "last_infer_s": _stats["last_infer_s"],
            "last_max_tokens": _stats["last_max_tokens"],
            "last_prompt_chars": _stats["last_prompt_chars"],
            "last_output_chars": _stats["last_output_chars"],
            "avg_prompt_chars": avg_prompt_chars,
            "avg_output_chars": avg_output_chars,
            "last_tokens_per_s": last_tokens_per_s,
            "total_tokens_per_s": total_tokens_per_s,
            "last_output_chars_per_s": last_output_chars_per_s,
            "last_lock_wait_ms": _stats["last_lock_wait_ms"],
            "last_llm_call_ms": _stats["last_llm_call_ms"],
            "avg_lock_wait_ms": avg_lock_wait_ms,
            "avg_llm_call_ms": avg_llm_call_ms,
            "last_non_llm_ms": last_non_llm_ms,
            "last_llm_share_pct": last_llm_share_pct,
        },
        "telemetry_hotspots": _telemetry_hotspots(),
    }

# ---------------------------------------------------------------------------
# Sandbox (QEMU/Alpine) — o server é o único dono do serial
# ---------------------------------------------------------------------------
_sandbox = None
_sandbox_guard = threading.Lock()     # criação do controller
_sandbox_run_lock = threading.Lock()  # serializa execuções (1 serial)


def _get_sandbox():
    global _sandbox
    with _sandbox_guard:
        if _sandbox is None:
            from engine.tools.sandbox_controller import SandboxController
            _sandbox = SandboxController()
        return _sandbox


def _handle_sandbox(req: dict[str, Any]) -> dict[str, Any]:
    action = str(req.get("sandbox", "run"))
    try:
        sb = _get_sandbox()
        if action == "status":
            st = sb.status()
            return {"online": st.online, "summary": st.summary(), "error": None}
        if action == "stop":
            sb.stop()
            return {"error": None}
        if action == "run":
            code = req.get("code")
            if not isinstance(code, str) or not code.strip():
                return {"error": "code vazio"}
            t0 = time.monotonic()
            with _sandbox_run_lock:
                r = sb.run(
                    code,
                    args=[str(a) for a in (req.get("args") or [])],
                    timeout=int(req.get("timeout", 30)),
                    lang=str(req.get("lang", "python")),
                )
            return {
                "success": r.success, "stdout": r.stdout, "stderr": r.stderr,
                "exit_code": r.exit_code,
                "elapsed_s": round(time.monotonic() - t0, 3), "error": None,
            }
        if action == "shell":
            with _sandbox_run_lock:
                out = sb.shell(str(req.get("cmd", "")),
                               timeout=float(req.get("timeout", 30)))
            return {"output": out, "error": None}
        return {"error": f"ação de sandbox inválida: {action}"}
    except Exception as exc:
        return {"error": str(exc), "traceback": traceback.format_exc()}

# ---------------------------------------------------------------------------
# Handler
# ---------------------------------------------------------------------------

def _handle(conn: socket.socket) -> None:
    resp: dict[str, Any] = {"output": "", "elapsed_s": 0, "error": "internal error"}
    streamed = False

    try:
        line = _read_line_from_socket(conn, timeout=10.0)
        if not line:
            resp = {"output": "", "elapsed_s": 0, "error": "payload vazio"}
            return

        if line.upper() == "STATUS":
            resp = _handle_status()
            return

        req_data = json.loads(line)

        if "sandbox" in req_data:
            resp = _handle_sandbox(req_data)
            return

        if "tokenize" in req_data:
            text = str(req_data["tokenize"])
            try:
                if _llm is None:
                    resp = {"tokens": [], "error": "modelo não carregado"}; return
                try:
                    tokens = _llm.tokenize(text.encode("utf-8"), add_bos=False)
                except TypeError:
                    tokens = _llm.tokenize(text.encode("utf-8"))
                resp = {"tokens": list(tokens), "error": None}
            except Exception as exc:
                resp = {"tokens": [], "error": str(exc)}
            return

        if "detokenize" in req_data:
            tokens = req_data["detokenize"]
            try:
                if _llm is None:
                    resp = {"text": "", "error": "modelo não carregado"}; return
                text = _llm.detokenize([int(t) for t in tokens]).decode("utf-8", errors="ignore")
                resp = {"text": text, "error": None}
            except Exception as exc:
                resp = {"text": "", "error": str(exc)}
            return

        prompt = str(req_data.get("prompt", "")).strip()
        max_tokens = max(1, min(int(req_data.get("max_tokens", 128)), 2048))
        stream = bool(req_data.get("stream", False))

        if not prompt:
            resp = {"output": "", "elapsed_s": 0, "error": "prompt vazio"}
            return

        with _lock:
            _stats["requests"] += 1

        try:
            if stream:
                streamed = True
                pieces: list[str] = []
                last_elapsed = 0.0
                conn.sendall(_json_line({"event": "start", "error": None}))
                for event in _infer_stream(prompt, max_tokens):
                    if event.get("done"):
                        last_elapsed = float(event.get("elapsed_s", 0.0))
                        final_text = str(event.get("delta", ""))
                        if final_text and not pieces:
                            pieces.append(final_text)
                        continue
                    delta = str(event.get("delta", ""))
                    if not delta:
                        continue
                    pieces.append(delta)
                    conn.sendall(_json_line({"event": "chunk", "delta": delta, "error": None}))

                output = "".join(pieces)
                elapsed = last_elapsed
                with _lock:
                    _stats["total_tokens"] += max_tokens
                    _stats["total_elapsed_s"] += elapsed
                    _stats["infer_calls"] += 1
                    _stats["last_infer_s"] = elapsed
                    _stats["last_prompt_chars"] = len(prompt)
                    _stats["last_output_chars"] = len(output)
                    _stats["last_max_tokens"] = max_tokens
                    _stats["sum_prompt_chars"] += len(prompt)
                    _stats["sum_output_chars"] += len(output)
                conn.sendall(_json_line({"event": "done", "output": output, "elapsed_s": elapsed, "error": None}))
                return

            output, elapsed = _infer(prompt, max_tokens)
            with _lock:
                _stats["total_tokens"] += max_tokens
                _stats["total_elapsed_s"] += elapsed
                _stats["infer_calls"] += 1
                _stats["last_infer_s"] = elapsed
                _stats["last_prompt_chars"] = len(prompt)
                _stats["last_output_chars"] = len(output)
                _stats["last_max_tokens"] = max_tokens
                _stats["sum_prompt_chars"] += len(prompt)
                _stats["sum_output_chars"] += len(output)

            resp = {"output": output, "elapsed_s": elapsed, "error": None}
        except Exception as e:
            with _lock:
                _stats["errors"] += 1
            resp = {
                "output": "",
                "elapsed_s": 0,
                "error": str(e),
                "traceback": traceback.format_exc(),
            }

    except json.JSONDecodeError as e:
        resp = {"output": "", "elapsed_s": 0, "error": f"JSON invalido: {e}"}
    except Exception as e:
        resp = {
            "output": "",
            "elapsed_s": 0,
            "error": f"handler: {e}",
            "traceback": traceback.format_exc(),
        }
    finally:
        if not streamed:
            try:
                conn.sendall(_json_line(resp))
            except Exception:
                pass
        try:
            conn.close()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Serve / shutdown
# ---------------------------------------------------------------------------

def _shutdown() -> None:
    global _llm, _native
    if _native is not None:
        try:
            _native.shutdown()
        except Exception:
            pass
        _native = None

    if _llm is not None:
        try:
            _llm.close()
        except Exception:
            pass
        _llm = None

    if _VULCAN_ACTIVE:
        try:
            from doxoade.tools.vulcan.runtime import uninstall_meta_finder
            uninstall_meta_finder()
        except Exception:
            pass

    if _sandbox is not None:
        try:
            if _sandbox.daemon._sock:
                _sandbox.daemon._sock.close()
        except Exception:
            pass

    _flush_telemetry_snapshot()
    PID_FILE.unlink(missing_ok=True)
    print("[SRV] Modelo liberado.", flush=True)


def _sigterm_handler(signum, frame):
    """Sinaliza shutdown limpo."""
    _shutdown_event.set()


def _serve(host: str, port: int) -> None:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv:
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind((host, port))
        srv.listen(BACKLOG)
        srv.settimeout(1.0)          # ← ESSENCIAL: desbloqueia a cada 1s
        print(f"[SERVER] Ouvindo em {host}:{port}", flush=True)

        while not _shutdown_event.is_set():
            try:
                conn, addr = srv.accept()
            except socket.timeout:
                continue              # ← verifica _shutdown_event e volta
            except OSError:
                break
            threading.Thread(target=_handle, args=(conn,), daemon=True).start()

    print("[SERVER] Loop encerrado.", flush=True)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

class ServerCLI:
    """Interface de linha de comando para orn-server."""

    def run(self, args: list[str]) -> None:
        if not args or args[0] == "start":
            start_args = args[1:] if args else []
            background = "--bg" in start_args

            cache_type_k = self._arg_value(start_args, "--cache-type-k")
            cache_type_v = self._arg_value(start_args, "--cache-type-v")
            active_window = self._arg_value(start_args, "--active-window")
            rope_freq_base = self._arg_value(start_args, "--rope-freq-base")
            rope_freq_scale = self._arg_value(start_args, "--rope-freq-scale")
            flash_attn = self._arg_value(start_args, "--flash-attn")
            min_p = self._arg_value(start_args, "--min-p")
            pin_threads = "--pin-threads" in start_args
            cont_batching = "--cont-batching" in start_args
            no_mmap = "--no-mmap" in start_args
            no_alloc = "--no-alloc" in start_args
            cpu_mask = self._arg_value(start_args, "--cpu-mask")
            cpuset = self._arg_value(start_args, "--cpuset")

            self._start(
                background=background,
                cache_type_k=cache_type_k,
                cache_type_v=cache_type_v,
                active_window=active_window,
                rope_freq_base=rope_freq_base,
                rope_freq_scale=rope_freq_scale,
                flash_attn=flash_attn,
                min_p=min_p,
                pin_threads=pin_threads,
                cont_batching=cont_batching,
                no_mmap=no_mmap,
                no_alloc=no_alloc,
                cpu_mask=cpu_mask,
                cpuset=cpuset,
            )
        elif args[0] == "stop":
            self._stop()
        elif args[0] == "status":
            self._status()
        elif args[0] == "ask":
            prompt = " ".join(args[1:]) if len(args) > 1 else ""
            tokens = 128
            if "--tokens" in args:
                idx = args.index("--tokens")
                tokens = int(args[idx + 1]) if idx + 1 < len(args) else 128
            self._ask(prompt, tokens)
        else:
            self._help()

    def _start(
        self,
        background: bool = False,
        cache_type_k: str | None = None,
        cache_type_v: str | None = None,
        active_window: str | None = None,
        rope_freq_base: str | None = None,
        rope_freq_scale: str | None = None,
        flash_attn: str | None = None,
        min_p: str | None = None,
        pin_threads: bool = False,
        cont_batching: bool = False,
        no_mmap: bool = False,
        no_alloc: bool = False,
        cpu_mask: str | None = None,
        cpuset: str | None = None,
    ) -> None:
        if self._is_online():
            print(f"[SRV] Servidor ja rodando na porta {PORT}.")
            return

        if background:
            log = open(LOG_FILE, "w", encoding="utf-8")
            child_args = [sys.executable, "-m", "engine.server.server", "start"]
            if cache_type_k:
                child_args += ["--cache-type-k", cache_type_k]
            if cache_type_v:
                child_args += ["--cache-type-v", cache_type_v]
            if active_window:
                child_args += ["--active-window", active_window]
            if rope_freq_base:
                child_args += ["--rope-freq-base", rope_freq_base]
            if rope_freq_scale:
                child_args += ["--rope-freq-scale", rope_freq_scale]
            if flash_attn:
                child_args += ["--flash-attn", flash_attn]
            if min_p:
                child_args += ["--min-p", min_p]
            if pin_threads:
                child_args += ["--pin-threads"]
            if cont_batching:
                child_args += ["--cont-batching"]
            if no_mmap:
                child_args += ["--no-mmap"]
            if no_alloc:
                child_args += ["--no-alloc"]
            if cpu_mask:
                child_args += ["--cpu-mask", cpu_mask]
            if cpuset:
                child_args += ["--cpuset", cpuset]

            subprocess.Popen(
                child_args,
                stdout=log,
                stderr=log,
                env=self._start_env(
                    cache_type_k,
                    cache_type_v,
                    active_window,
                    rope_freq_base,
                    rope_freq_scale,
                    flash_attn,
                    min_p,
                    pin_threads,
                    cont_batching,
                    no_mmap,
                    no_alloc,
                    cpu_mask,
                    cpuset,
                ),
                creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0),
            )
            log.close()
            print(f"[SRV] Iniciado em background. Log: {LOG_FILE}")
            print("[SRV] Aguarde ~5s e verifique: orn-server status")
            return

        try:
            # Mantém SIGTERM ativo para quando usar o comando 'stop' via background.
            signal.signal(signal.SIGTERM, _sigterm_handler)
            # Removemos o hook de SIGINT. Agora o Ctrl+C levanta um KeyboardInterrupt
            # natural no socket.accept(), permitindo o desmonte limpo da pilha pro cProfile!
        except Exception:
            pass

        self._apply_start_env(
            cache_type_k,
            cache_type_v,
            active_window,
            rope_freq_base,
            rope_freq_scale,
            flash_attn,
            min_p,
            pin_threads,
            cont_batching,
            no_mmap,
            no_alloc,
            cpu_mask,
            cpuset,
        )
        _load_model()

        # Grava PID para que _stop() consiga matar o processo
        try:
            PID_FILE.write_text(str(os.getpid()))
        except Exception as e:
            print(f"[WARN] Nao foi possivel gravar server.pid: {e}", flush=True)

        try:
            _serve(HOST, PORT)          # ← passa os argumentos
        except KeyboardInterrupt:
            print("\n[SRV] Interrompido pelo usuario (Ctrl+C).", flush=True)
        finally:
            _shutdown()

    def _stop(self) -> None:
        if not PID_FILE.exists():
            print("[STOP] server.pid nao encontrado — servidor ja parou?")
            return
        try:
            pid = int(PID_FILE.read_text().strip())
        except (ValueError, OSError) as e:
            print(f"[STOP] Erro ao ler server.pid: {e}")
            return

        try:
            if os.name == "nt":
                # Windows: SIGTERM nao existe — usa taskkill
                import subprocess
                subprocess.run(
                    ["taskkill", "/PID", str(pid), "/F"],
                    check=False,
                    capture_output=True,
                )
            else:
                import signal as _signal
                os.kill(pid, _signal.SIGTERM)

            print(f"[STOP] Sinal enviado para PID {pid}.")
        except (ProcessLookupError, PermissionError) as e:
            print(f"[STOP] Processo {pid} nao encontrado ou sem permissao: {e}")
        finally:
            PID_FILE.unlink(missing_ok=True)

    def _status(self) -> None:
        resp = self._query_status()
        if resp is None:
            print("[SRV] Offline.")
            return

        up = resp.get("uptime_s", 0)
        h, rem = divmod(int(up), 3600)
        m, s = divmod(rem, 60)

        print("  Status:      ONLINE")
        print(f"  Uptime:      {h:02d}:{m:02d}:{s:02d}")
        print(f"  Requests:    {resp['requests']}")
        print(f"  Errors:      {resp['errors']}")
        print(f"  Tokens:      {resp['total_tokens']}")
        print(f"  Avg latency: {resp.get('avg_elapsed_s', 0)}s")
        print(f"  Porta:       {resp.get('port', PORT)}")
        vulcan_str = "ATIVO" if resp.get("vulcan") else "Python puro"
        print(f"  Vulcan:      {vulcan_str}")
        if not resp.get("vulcan"):
            for line in resp.get("vulcan_detail", "").splitlines()[:4]:
                print(f"               {line}")

        boot_perf = resp.get("boot_perf", {})
        if boot_perf:
            print("  Boot perf:")
            print(f"    - vulcan_boot_ms={boot_perf.get('vulcan_boot_ms', 0)}")
            print(f"    - model_load_ms={boot_perf.get('model_load_ms', 0)}")

        system_perf = resp.get("system_perf", {})
        if system_perf:
            print("  System perf:")
            print(f"    - pid={system_perf.get('pid', 0)} threads={system_perf.get('threads', 0)}")
            print(f"    - cpu_count={system_perf.get('cpu_count', 0)} load_1m={system_perf.get('load_1m', 0)}")
            print(f"    - rss_mb={system_perf.get('rss_mb', 0)}")

        ai_perf = resp.get("ai_perf", {})
        if ai_perf:
            print("  IA perf:")
            print(f"    - infer_calls={ai_perf.get('infer_calls', 0)}")
            print(f"    - last_infer_s={ai_perf.get('last_infer_s', 0)}")
            print(f"    - last_tokens_per_s={ai_perf.get('last_tokens_per_s', 0)}")
            print(f"    - total_tokens_per_s={ai_perf.get('total_tokens_per_s', 0)}")
            print(f"    - last_prompt_chars={ai_perf.get('last_prompt_chars', 0)}")
            print(f"    - last_output_chars={ai_perf.get('last_output_chars', 0)}")
            print(f"    - last_lock_wait_ms={ai_perf.get('last_lock_wait_ms', 0)}")
            print(f"    - last_llm_call_ms={ai_perf.get('last_llm_call_ms', 0)}")
            print(f"    - last_non_llm_ms={ai_perf.get('last_non_llm_ms', 0)}")
            print(f"    - last_llm_share_pct={ai_perf.get('last_llm_share_pct', 0)}")

        hotspots = resp.get("telemetry_hotspots", [])
        if hotspots:
            print("  Telemetria (hotspots):")
            for row in hotspots[:3]:
                print(
                    "    - "
                    f"{row.get('name','?')} calls={row.get('calls', 0)} "
                    f"avg={row.get('avg_ms', 0)}ms p95={row.get('p95_ms', 0)}ms"
                )

    def _ask(self, prompt: str, max_tokens: int = 128) -> None:
        if not prompt:
            print("[ERRO] Forneca um prompt: orn-server ask 'sua pergunta'")
            return

        resp = self._query(prompt, max_tokens)
        if resp is None:
            print("[ERRO] Servidor offline. Execute: orn-server start")
            return

        if resp.get("error"):
            print(f"[ERRO] {resp['error']}")
            if resp.get("traceback"):
                print(resp["traceback"])
        else:
            print(resp["output"])
            print(f"\n[{resp['elapsed_s']}s]")

    @staticmethod
    def _arg_value(args: list[str], flag: str) -> str | None:
        if flag not in args:
            return None
        idx = args.index(flag)
        if idx + 1 >= len(args):
            return None
        value = args[idx + 1].strip()
        return value or None

    @staticmethod
    def _start_env(
        cache_type_k: str | None,
        cache_type_v: str | None,
        active_window: str | None,
        rope_freq_base: str | None,
        rope_freq_scale: str | None,
        flash_attn: str | None,
        min_p: str | None,
        pin_threads: bool,
        cont_batching: bool,
        no_mmap: bool,
        no_alloc: bool,
        cpu_mask: str | None,
        cpuset: str | None,
    ) -> dict[str, str]:
        env = os.environ.copy()
        if cache_type_k:
            env["ORN_CACHE_TYPE_K"] = cache_type_k
        if cache_type_v:
            env["ORN_CACHE_TYPE_V"] = cache_type_v
        if active_window:
            env["ORN_ACTIVE_WINDOW"] = active_window
        if rope_freq_base:
            env["ORN_ROPE_FREQ_BASE"] = rope_freq_base
        if rope_freq_scale:
            env["ORN_ROPE_FREQ_SCALE"] = rope_freq_scale
        if flash_attn:
            env["ORN_FLASH_ATTN"] = flash_attn
        if min_p:
            env["ORN_MIN_P"] = min_p
        if pin_threads:
            env["ORN_PIN_THREADS"] = "1"
        if cont_batching:
            env["ORN_CONT_BATCHING"] = "1"
        if no_mmap:
            env["ORN_USE_MMAP"] = "0"
        if no_alloc:
            env["ORN_NO_ALLOC"] = "1"
        if cpu_mask:
            env["ORN_CPU_MASK"] = cpu_mask
        if cpuset:
            env["ORN_CPUSET"] = cpuset

        root = _discover_doxoade_root()
        if root:
            env["DOXOADE_ROOT"] = root
        return env

    def _apply_start_env(
        self,
        cache_type_k: str | None,
        cache_type_v: str | None,
        active_window: str | None,
        rope_freq_base: str | None,
        rope_freq_scale: str | None,
        flash_attn: str | None,
        min_p: str | None,
        pin_threads: bool,
        cont_batching: bool,
        no_mmap: bool,
        no_alloc: bool,
        cpu_mask: str | None,
        cpuset: str | None,
    ) -> None:
        env = self._start_env(
            cache_type_k,
            cache_type_v,
            active_window,
            rope_freq_base,
            rope_freq_scale,
            flash_attn,
            min_p,
            pin_threads,
            cont_batching,
            no_mmap,
            no_alloc,
            cpu_mask,
            cpuset,
        )
        os.environ.update(env)

    def _help(self) -> None:
        print("orn-server <comando> [opcoes]")
        print("  start          inicia servidor (foreground)")
        print("  start --bg     inicia em background")
        print("  start --active-window 512")
        print("  start --cache-type-k q8_0 --cache-type-v q4_0")
        print("  start --cache-type-k none --cache-type-v off")
        print("  start --rope-freq-base 10000 --rope-freq-scale 1.0")
        print("  start --flash-attn on")
        print("  start --min-p 0.01")
        print("  start --pin-threads --cont-batching")
        print("  start --cpu-mask 0x3")
        print("  start --cpuset 0,1")
        print("  start --no-mmap --no-alloc")
        print("  stop           para o servidor")
        print("  status         exibe uptime e estatisticas")
        print('  ask "prompt"   consulta direta ao modelo')
        print('  ask "prompt" --tokens 200')

    def _is_online(self) -> bool:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(1.0)
                s.connect((HOST, PORT))
            return True
        except (ConnectionRefusedError, OSError):
            return False

    def _query_status(self) -> dict[str, Any] | None:
        return self._raw_query(b"STATUS\n")

    def _query(self, prompt: str, max_tokens: int) -> dict[str, Any] | None:
        payload = (json.dumps({"prompt": prompt, "max_tokens": max_tokens}) + "\n").encode("utf-8")
        return self._raw_query(payload)

    def _raw_query(self, payload: bytes) -> dict[str, Any] | None:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(60.0)
                s.connect((HOST, PORT))
                s.settimeout(None)
                s.sendall(payload)
                data = bytearray()
                while True:
                    chunk = s.recv(65536)
                    if not chunk:
                        break
                    data.extend(chunk)
                    if data.endswith(b"\n"):
                        break
            return json.loads(data.decode("utf-8").strip())
        except Exception:
            return None


def main(argv: list[str] | None = None) -> None:
    cli = ServerCLI()
    cli.run(list(sys.argv[1:] if argv is None else argv))


if __name__ == "__main__":
    main()
